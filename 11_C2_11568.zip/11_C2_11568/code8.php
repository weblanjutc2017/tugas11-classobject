<?php
class smartphone {
 // buat konstanta
 const RUPIAH = '3000000';
}

// panggil konstanta class
echo "Harga smartphone saat ini = Rp. ".smartphone::RUPIAH;
?>